#include <stdio.h>
#include <stdint.h>

void superstring(char article[], char dictionary[]) {
