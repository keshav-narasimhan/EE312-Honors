#include <stdio.h>
#include <stdint.h>

void printSuperStrings(char article[], char dictionary[]) {
    int *a = 0;
    printf("%d\n", *a);
}
