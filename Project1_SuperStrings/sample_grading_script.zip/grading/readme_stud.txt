HOW TO RUN THE GRADING SCRIPT

Copy the sample_grading_script.zip to any place on ECE LRC machine. Unzip it using: unzip sample_grading_script.zip, this should generate a folder called 

Then copy your Project1.cpp into teh 'submissions' 
Place Project1.cpp into the 'submissions' directory.
Then run ./grade.sh .

CAUTION: your submission file Project1.cpp will be deleted after grading, so keep a copy!
