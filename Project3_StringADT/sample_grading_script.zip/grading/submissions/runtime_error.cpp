#include <stdint.h>
#include "UTString.h"

UTString* utstrdup(const char* src) { int *x=0; *x=1; return 0; }
uint32_t utstrlen(const UTString* s) { int *x=0; *x=1; return 0; }
UTString* utstrcat(UTString* s, const char* suffix) { int *x=0; *x=1; return 0; }
UTString* utstrcpy(UTString* dst, const char* src) { int *x=0; *x=1; return 0; }
void utstrfree(UTString* self) { int *x=0; *x=1; return ; }
UTString* utstrrealloc(UTString* s, uint32_t new_capacity) { int *x=0; *x=1; return 0; }
