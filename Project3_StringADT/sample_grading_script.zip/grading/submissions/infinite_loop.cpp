#include <stdint.h>
#include "UTString.h"

UTString* utstrdup(const char* src) { while(1); return 0; }
uint32_t utstrlen(const UTString* s) { while(1); return 0; }
UTString* utstrcat(UTString* s, const char* suffix) { while(1); return 0; }
UTString* utstrcpy(UTString* dst, const char* src) { while(1); return 0; }
void utstrfree(UTString* self) { while(1); return ; }
UTString* utstrrealloc(UTString* s, uint32_t new_capacity) { while(1); return 0; }
